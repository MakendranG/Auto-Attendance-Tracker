#!/usr/bin/env python3
"""
PDF Parser for Attendance Data
Extracts attendance information from college PDF reports
"""

import re
import pandas as pd
from typing import List, Dict, Optional

class AttendancePDFParser:
    def __init__(self):
        self.patterns = {
            # Common patterns found in TN college attendance PDFs
            'subject_attendance': [
                r'([A-Z][A-Za-z\s&-]+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+\.?\d*)%',
                r'([A-Z][A-Za-z\s&-]+)\s+(\d+)/(\d+)\s+(\d+\.?\d*)%',
                r'Subject:\s*([A-Za-z\s&-]+)\s+Total:\s*(\d+)\s+Present:\s*(\d+)\s+Percentage:\s*(\d+\.?\d*)%'
            ],
            'student_info': [
                r'Name:\s*([A-Za-z\s\.]+)',
                r'Roll\s*No:\s*([A-Z0-9]+)',
                r'Semester:\s*([IVX\d]+)',
                r'Department:\s*([A-Za-z\s&]+)'
            ]
        }
    
    def extract_text_from_pdf(self, pdf_path: str) -> str:
        """Extract text from PDF file"""
        try:
            import PyPDF2
            
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                text = ""
                
                for page in pdf_reader.pages:
                    text += page.extract_text() + "\n"
                
                return text
        
        except ImportError:
            print("❌ PyPDF2 not installed. Install with: pip install PyPDF2")
            return ""
        except Exception as e:
            print(f"❌ Error reading PDF: {e}")
            return ""
    
    def parse_attendance_data(self, text: str) -> Dict:
        """Parse attendance data from extracted text"""
        attendance_data = {
            'student_info': {},
            'subjects': {}
        }
        
        # Extract student information
        for pattern in self.patterns['student_info']:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                if 'name' not in attendance_data['student_info'] and 'Name' in pattern:
                    attendance_data['student_info']['name'] = matches[0].strip()
                elif 'roll' not in attendance_data['student_info'] and 'Roll' in pattern:
                    attendance_data['student_info']['roll_no'] = matches[0].strip()
                elif 'semester' not in attendance_data['student_info'] and 'Semester' in pattern:
                    attendance_data['student_info']['semester'] = matches[0].strip()
                elif 'department' not in attendance_data['student_info'] and 'Department' in pattern:
                    attendance_data['student_info']['department'] = matches[0].strip()
        
        # Extract attendance data
        for pattern in self.patterns['subject_attendance']:
            matches = re.findall(pattern, text, re.IGNORECASE)
            
            for match in matches:
                if len(match) == 5:  # Pattern with total, present, absent, percentage
                    subject, total, present, absent, percentage = match
                    attendance_data['subjects'][subject.strip()] = {
                        'total_classes': int(total),
                        'present': int(present),
                        'absent': int(absent),
                        'percentage': float(percentage)
                    }
                elif len(match) == 4:  # Pattern with present/total, percentage
                    subject, present, total, percentage = match
                    absent = int(total) - int(present)
                    attendance_data['subjects'][subject.strip()] = {
                        'total_classes': int(total),
                        'present': int(present),
                        'absent': absent,
                        'percentage': float(percentage)
                    }
        
        return attendance_data
    
    def convert_to_csv(self, attendance_data: Dict, output_file: str = "extracted_attendance.csv"):
        """Convert parsed data to CSV format"""
        subjects_data = []
        
        for subject, data in attendance_data['subjects'].items():
            subjects_data.append({
                'Subject': subject,
                'Total_Classes': data['total_classes'],
                'Present_Classes': data['present'],
                'Absent_Classes': data['absent']
            })
        
        df = pd.DataFrame(subjects_data)
        df.to_csv(output_file, index=False)
        
        print(f"✅ Attendance data exported to {output_file}")
        return output_file
    
    def process_pdf(self, pdf_path: str, output_csv: str = "extracted_attendance.csv") -> Optional[str]:
        """Complete PDF processing pipeline"""
        print(f"📄 Processing PDF: {pdf_path}")
        
        # Extract text
        text = self.extract_text_from_pdf(pdf_path)
        if not text:
            return None
        
        # Parse attendance data
        attendance_data = self.parse_attendance_data(text)
        
        if not attendance_data['subjects']:
            print("❌ No attendance data found in PDF")
            return None
        
        # Convert to CSV
        csv_file = self.convert_to_csv(attendance_data, output_csv)
        
        # Print summary
        print(f"\n📊 Extracted Data Summary:")
        if attendance_data['student_info']:
            for key, value in attendance_data['student_info'].items():
                print(f"  {key.title()}: {value}")
        
        print(f"  Subjects found: {len(attendance_data['subjects'])}")
        for subject in attendance_data['subjects'].keys():
            print(f"    • {subject}")
        
        return csv_file

def main():
    """Main function for PDF parsing"""
    parser = AttendancePDFParser()
    
    print("📄 PDF Attendance Parser")
    print("Extract attendance data from college PDF reports")
    print()
    
    pdf_path = input("Enter PDF file path: ").strip()
    
    if not pdf_path.endswith('.pdf'):
        print("❌ Please provide a valid PDF file")
        return
    
    output_csv = input("Enter output CSV filename (or press Enter for default): ").strip()
    if not output_csv:
        output_csv = "extracted_attendance.csv"
    
    csv_file = parser.process_pdf(pdf_path, output_csv)
    
    if csv_file:
        print(f"\n✅ Success! Use '{csv_file}' with the main attendance tracker.")
        
        # Ask if user wants to load into tracker immediately
        load_now = input("\nLoad into attendance tracker now? (y/n): ").lower().strip()
        if load_now == 'y':
            from attendance_tracker import AttendanceTracker
            
            tracker = AttendanceTracker()
            if tracker.load_from_csv(csv_file):
                print(tracker.generate_report())

if __name__ == "__main__":
    main()