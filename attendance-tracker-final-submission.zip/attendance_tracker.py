#!/usr/bin/env python3
"""
Auto-Attendance Tracker for Tamil Nadu College Students
Automatically calculates attendance percentages from PDFs or CSVs
"""

import pandas as pd
import json
import os
from datetime import datetime
from typing import Dict, List, Tuple
import re

class AttendanceTracker:
    def __init__(self):
        self.subjects = {}
        self.minimum_attendance = 75  # Default minimum attendance percentage
        self.student_name = ""
        self.semester = ""
        
    def load_from_csv(self, csv_file: str) -> bool:
        """Load attendance data from CSV file"""
        try:
            df = pd.read_csv(csv_file)
            
            # Expected CSV format: Subject, Total_Classes, Present_Classes, Absent_Classes
            for _, row in df.iterrows():
                subject = row['Subject']
                total = int(row['Total_Classes'])
                present = int(row['Present_Classes'])
                absent = int(row['Absent_Classes'])
                
                percentage = (present / total) * 100 if total > 0 else 0
                
                self.subjects[subject] = {
                    'total_classes': total,
                    'present': present,
                    'absent': absent,
                    'percentage': round(percentage, 2)
                }
            
            return True
        except Exception as e:
            print(f"Error loading CSV: {e}")
            return False
    
    def add_subject_manually(self, subject: str, total: int, present: int):
        """Manually add subject attendance data"""
        absent = total - present
        percentage = (present / total) * 100 if total > 0 else 0
        
        self.subjects[subject] = {
            'total_classes': total,
            'present': present,
            'absent': absent,
            'percentage': round(percentage, 2)
        }
    
    def calculate_required_classes(self, subject: str, target_percentage: float = None) -> int:
        """Calculate how many classes needed to reach target percentage"""
        if subject not in self.subjects:
            return 0
            
        if target_percentage is None:
            target_percentage = self.minimum_attendance
            
        data = self.subjects[subject]
        present = data['present']
        total = data['total_classes']
        
        # Formula: (present + x) / (total + x) = target/100
        # Solving for x: x = (target*total - 100*present) / (100 - target)
        
        if target_percentage >= 100:
            return 0
            
        numerator = (target_percentage * total) - (100 * present)
        denominator = 100 - target_percentage
        
        if denominator <= 0:
            return 0
            
        required = numerator / denominator
        return max(0, int(required) + (1 if required > int(required) else 0))
    
    def get_low_attendance_subjects(self) -> List[str]:
        """Get subjects with attendance below minimum threshold"""
        low_subjects = []
        for subject, data in self.subjects.items():
            if data['percentage'] < self.minimum_attendance:
                low_subjects.append(subject)
        return low_subjects
    
    def generate_report(self) -> str:
        """Generate detailed attendance report"""
        report = []
        report.append("=" * 60)
        report.append("📚 ATTENDANCE TRACKER REPORT")
        report.append("=" * 60)
        
        if self.student_name:
            report.append(f"Student: {self.student_name}")
        if self.semester:
            report.append(f"Semester: {self.semester}")
        
        report.append(f"Minimum Required Attendance: {self.minimum_attendance}%")
        report.append(f"Report Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("")
        
        # Overall statistics
        total_classes = sum(data['total_classes'] for data in self.subjects.values())
        total_present = sum(data['present'] for data in self.subjects.values())
        overall_percentage = (total_present / total_classes * 100) if total_classes > 0 else 0
        
        report.append(f"📊 OVERALL STATISTICS")
        report.append(f"Total Classes: {total_classes}")
        report.append(f"Classes Attended: {total_present}")
        report.append(f"Overall Attendance: {overall_percentage:.2f}%")
        report.append("")
        
        # Subject-wise breakdown
        report.append("📋 SUBJECT-WISE BREAKDOWN")
        report.append("-" * 60)
        
        for subject, data in sorted(self.subjects.items()):
            status = "✅ SAFE" if data['percentage'] >= self.minimum_attendance else "⚠️  LOW"
            
            report.append(f"Subject: {subject}")
            report.append(f"  Classes: {data['present']}/{data['total_classes']} ({data['percentage']:.2f}%) {status}")
            
            if data['percentage'] < self.minimum_attendance:
                required = self.calculate_required_classes(subject)
                report.append(f"  ⚡ Need to attend {required} more classes to reach {self.minimum_attendance}%")
            
            report.append("")
        
        # Low attendance warning
        low_subjects = self.get_low_attendance_subjects()
        if low_subjects:
            report.append("🚨 LOW ATTENDANCE WARNING")
            report.append("-" * 60)
            for subject in low_subjects:
                data = self.subjects[subject]
                required = self.calculate_required_classes(subject)
                report.append(f"• {subject}: {data['percentage']:.2f}% (Need {required} more classes)")
            report.append("")
        
        return "\n".join(report)
    
    def save_to_json(self, filename: str = "attendance_data.json"):
        """Save attendance data to JSON file"""
        data = {
            'student_name': self.student_name,
            'semester': self.semester,
            'minimum_attendance': self.minimum_attendance,
            'subjects': self.subjects,
            'last_updated': datetime.now().isoformat()
        }
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"✅ Attendance data saved to {filename}")
    
    def load_from_json(self, filename: str = "attendance_data.json"):
        """Load attendance data from JSON file"""
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
            
            self.student_name = data.get('student_name', '')
            self.semester = data.get('semester', '')
            self.minimum_attendance = data.get('minimum_attendance', 75)
            self.subjects = data.get('subjects', {})
            
            print(f"✅ Attendance data loaded from {filename}")
            return True
        except FileNotFoundError:
            print(f"❌ File {filename} not found")
            return False
        except Exception as e:
            print(f"❌ Error loading data: {e}")
            return False

def main():
    """Main function to run the attendance tracker"""
    tracker = AttendanceTracker()
    
    print("🎓 Welcome to Auto-Attendance Tracker!")
    print("Perfect for Tamil Nadu college students!")
    print()
    
    # Check if saved data exists
    if os.path.exists("attendance_data.json"):
        load_existing = input("Found existing data. Load it? (y/n): ").lower().strip()
        if load_existing == 'y':
            tracker.load_from_json()
    
    while True:
        print("\n📚 ATTENDANCE TRACKER MENU")
        print("1. Load from CSV file")
        print("2. Add subject manually")
        print("3. View attendance report")
        print("4. Set minimum attendance percentage")
        print("5. Set student details")
        print("6. Save data")
        print("7. Exit")
        
        choice = input("\nEnter your choice (1-7): ").strip()
        
        if choice == '1':
            csv_file = input("Enter CSV file path: ").strip()
            if tracker.load_from_csv(csv_file):
                print("✅ CSV data loaded successfully!")
            else:
                print("❌ Failed to load CSV data")
        
        elif choice == '2':
            subject = input("Enter subject name: ").strip()
            try:
                total = int(input("Enter total classes: "))
                present = int(input("Enter classes attended: "))
                tracker.add_subject_manually(subject, total, present)
                print(f"✅ Added {subject} successfully!")
            except ValueError:
                print("❌ Please enter valid numbers")
        
        elif choice == '3':
            if not tracker.subjects:
                print("❌ No attendance data available. Please add some data first.")
            else:
                print(tracker.generate_report())
        
        elif choice == '4':
            try:
                new_min = float(input(f"Current minimum: {tracker.minimum_attendance}%. Enter new minimum: "))
                tracker.minimum_attendance = new_min
                print(f"✅ Minimum attendance set to {new_min}%")
            except ValueError:
                print("❌ Please enter a valid percentage")
        
        elif choice == '5':
            tracker.student_name = input("Enter student name: ").strip()
            tracker.semester = input("Enter semester/year: ").strip()
            print("✅ Student details updated!")
        
        elif choice == '6':
            tracker.save_to_json()
        
        elif choice == '7':
            print("👋 Thanks for using Attendance Tracker!")
            break
        
        else:
            print("❌ Invalid choice. Please try again.")

if __name__ == "__main__":
    main()