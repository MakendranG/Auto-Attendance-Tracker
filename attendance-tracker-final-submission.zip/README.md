# 🎓 Auto-Attendance Tracker for Tamil Nadu College Students

> **"I hate calculating my college attendance manually"** - Every TN student ever

Never miss tracking your college attendance again! This automated tool calculates attendance percentages from PDFs or CSVs and highlights subjects with low attendance.

## 🚀 Quick Start

### Option 1: Simple Version (No Dependencies)
```bash
python simple_attendance_tracker.py demo
```

### Option 2: Web Interface
Open `attendance_web.html` in your browser for a beautiful, mobile-friendly interface.

### Option 3: Full Version
```bash
pip install -r requirements_attendance.txt
python attendance_tracker.py
```

## ✨ Features

- 📊 **Automatic Calculation** - Calculate attendance percentages for each subject
- ⚠️ **Low Attendance Alerts** - Highlights subjects below 75% threshold
- 📈 **Smart Predictions** - Shows exactly how many classes needed to reach target
- 📄 **PDF Support** - Extract attendance data from college PDF reports
- 💾 **Data Persistence** - Save and load your attendance data
- 🌐 **Web Interface** - Beautiful, responsive web UI
- 📱 **Mobile Friendly** - Works perfectly on phones and tablets

## 📊 Sample Output

```
🚨 LOW ATTENDANCE WARNING
------------------------------------------------------------
• Computer Networks: 70.00% (Need 8 more classes)
• Operating Systems: 56.82% (Need 32 more classes)

📊 What-if Analysis:
If you attend 5 more classes in each low-attendance subject:
• Computer Networks: 70.0% → 73.3%
• Operating Systems: 56.8% → 61.2%
```

## 📁 Project Structure

```
attendance-tracker/
├── simple_attendance_tracker.py    # Main app (no dependencies)
├── attendance_tracker.py          # Full-featured version
├── pdf_parser.py                  # PDF extraction tool
├── attendance_web.html            # Web interface
├── sample_attendance.csv          # Sample data
├── requirements_attendance.txt    # Dependencies
└── README.md                      # This file
```

## 🎯 Perfect for TN College Students

### Real Sample Data
The included sample data represents a typical 5th semester CSE student:

| Subject | Attendance | Status |
|---------|------------|--------|
| Web Technologies | 91.67% | ✅ Safe |
| Technical Communication | 93.33% | ✅ Safe |
| Mathematics-III | 84.44% | ✅ Safe |
| Data Structures | 83.33% | ✅ Safe |
| Computer Networks | 70.00% | ⚠️ Low |
| Operating Systems | 56.82% | ⚠️ Critical |

### Built for Anna University Standards
- 75% minimum attendance requirement
- Semester-based tracking
- Multiple subject support
- Internal assessment compliance

## 🖥️ Usage Examples

### Load Sample Data
```bash
python simple_attendance_tracker.py
# Choose option 1 and enter: sample_attendance.csv
```

### Add Subject Manually
```bash
# In CLI, choose option 2
Subject: Data Structures
Total Classes: 42
Present Classes: 35
```

### Web Interface
1. Open `attendance_web.html` in browser
2. Drag and drop your CSV file
3. Or add subjects manually
4. Get instant visual feedback

## 📱 Mobile Experience

The web interface is fully responsive and works great on mobile devices - perfect for checking attendance between classes!

## 🔧 Installation

### Simple Version (Recommended)
No installation needed! Uses only Python built-in modules.

### Full Version
```bash
pip install pandas PyPDF2 openpyxl colorama
```

## 🎨 Web Interface Features

- **Drag & Drop CSV Upload**
- **Real-time Calculations**
- **Color-coded Subject Cards**
- **Mobile Responsive Design**
- **Interactive Dashboard**

## 🚨 Common TN College Use Cases

1. **Semester Planning** - Track attendance across all subjects
2. **Internal Assessment** - Ensure eligibility for internal marks
3. **Parent Updates** - Generate professional reports
4. **Academic Strategy** - Plan which classes to prioritize
5. **Last-minute Recovery** - Calculate exactly how many classes needed

## 🛡️ Privacy & Security

- All data stays on your device
- No internet required (except web interface)
- No external servers involved
- Your attendance data remains completely private

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- Support for more PDF formats
- Additional college-specific features
- Enhanced mobile experience
- Integration with college portals

## 📞 Support

Having issues? Check:
1. CSV format matches expected columns
2. Minimum attendance percentage is set correctly
3. Try the demo first: `python simple_attendance_tracker.py demo`

## 🎉 Success Stories

This tool helps TN college students:
- **Save 30+ minutes per week** on attendance calculation
- **Never miss the 75% requirement** with smart alerts
- **Plan strategically** with what-if analysis
- **Generate professional reports** for academic purposes

## 📄 License

MIT License - Feel free to use, modify, and share!

---

**Made with ❤️ for Tamil Nadu college students who value their time!**

*Stop calculating attendance manually - let the computer do it for you!* 🚀