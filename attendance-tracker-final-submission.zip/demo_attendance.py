#!/usr/bin/env python3
"""
Demo script for Attendance Tracker
Shows the functionality with sample data
"""

from attendance_tracker import AttendanceTracker

def run_demo():
    """Run a complete demo of the attendance tracker"""
    print("🎓 ATTENDANCE TRACKER DEMO")
    print("=" * 50)
    print("Loading sample data for a TN college student...")
    print()
    
    # Create tracker instance
    tracker = AttendanceTracker()
    
    # Set student details
    tracker.student_name = "Priya Sharma"
    tracker.semester = "5th Semester - CSE"
    tracker.minimum_attendance = 75
    
    # Load sample data from CSV
    if tracker.load_from_csv("sample_attendance.csv"):
        print("✅ Sample data loaded successfully!")
        print()
        
        # Generate and display report
        print(tracker.generate_report())
        
        # Show specific calculations
        print("\n🔍 DETAILED ANALYSIS")
        print("-" * 50)
        
        low_subjects = tracker.get_low_attendance_subjects()
        if low_subjects:
            print("⚠️  Subjects needing immediate attention:")
            for subject in low_subjects:
                data = tracker.subjects[subject]
                required = tracker.calculate_required_classes(subject)
                print(f"  • {subject}: {data['percentage']:.1f}% - Need {required} more classes")
        
        print("\n📊 What-if Analysis:")
        print("If you attend 5 more classes in each low-attendance subject:")
        
        for subject in low_subjects:
            data = tracker.subjects[subject]
            new_present = data['present'] + 5
            new_total = data['total_classes'] + 5
            new_percentage = (new_present / new_total) * 100
            
            print(f"  • {subject}: {data['percentage']:.1f}% → {new_percentage:.1f}%")
        
        # Save demo data
        tracker.save_to_json("demo_attendance_data.json")
        
        print(f"\n💾 Demo data saved to 'demo_attendance_data.json'")
        print("🌐 Open 'attendance_web.html' in your browser to see the web interface!")
        
    else:
        print("❌ Could not load sample data. Make sure 'sample_attendance.csv' exists.")

if __name__ == "__main__":
    run_demo()