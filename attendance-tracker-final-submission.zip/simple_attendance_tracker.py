#!/usr/bin/env python3
"""
Simple Auto-Attendance Tracker for Tamil Nadu College Students
No external dependencies required - uses only built-in Python modules
"""

import json
import csv
import os
from datetime import datetime
from typing import Dict, List

class SimpleAttendanceTracker:
    def __init__(self):
        self.subjects = {}
        self.minimum_attendance = 75
        self.student_name = ""
        self.semester = ""
        
    def load_from_csv(self, csv_file: str) -> bool:
        """Load attendance data from CSV file"""
        try:
            with open(csv_file, 'r', newline='', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                
                for row in reader:
                    subject = row['Subject'].strip()
                    total = int(row['Total_Classes'])
                    present = int(row['Present_Classes'])
                    absent = int(row['Absent_Classes'])
                    
                    percentage = (present / total) * 100 if total > 0 else 0
                    
                    self.subjects[subject] = {
                        'total_classes': total,
                        'present': present,
                        'absent': absent,
                        'percentage': round(percentage, 2)
                    }
            
            return True
        except Exception as e:
            print(f"Error loading CSV: {e}")
            return False
    
    def add_subject_manually(self, subject: str, total: int, present: int):
        """Manually add subject attendance data"""
        absent = total - present
        percentage = (present / total) * 100 if total > 0 else 0
        
        self.subjects[subject] = {
            'total_classes': total,
            'present': present,
            'absent': absent,
            'percentage': round(percentage, 2)
        }
    
    def calculate_required_classes(self, subject: str, target_percentage: float = None) -> int:
        """Calculate how many classes needed to reach target percentage"""
        if subject not in self.subjects:
            return 0
            
        if target_percentage is None:
            target_percentage = self.minimum_attendance
            
        data = self.subjects[subject]
        present = data['present']
        total = data['total_classes']
        
        if target_percentage >= 100:
            return 0
            
        numerator = (target_percentage * total) - (100 * present)
        denominator = 100 - target_percentage
        
        if denominator <= 0:
            return 0
            
        required = numerator / denominator
        return max(0, int(required) + (1 if required > int(required) else 0))
    
    def get_low_attendance_subjects(self) -> List[str]:
        """Get subjects with attendance below minimum threshold"""
        low_subjects = []
        for subject, data in self.subjects.items():
            if data['percentage'] < self.minimum_attendance:
                low_subjects.append(subject)
        return low_subjects
    
    def generate_report(self) -> str:
        """Generate detailed attendance report"""
        report = []
        report.append("=" * 60)
        report.append("📚 ATTENDANCE TRACKER REPORT")
        report.append("=" * 60)
        
        if self.student_name:
            report.append(f"Student: {self.student_name}")
        if self.semester:
            report.append(f"Semester: {self.semester}")
        
        report.append(f"Minimum Required Attendance: {self.minimum_attendance}%")
        report.append(f"Report Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("")
        
        # Overall statistics
        total_classes = sum(data['total_classes'] for data in self.subjects.values())
        total_present = sum(data['present'] for data in self.subjects.values())
        overall_percentage = (total_present / total_classes * 100) if total_classes > 0 else 0
        
        report.append(f"📊 OVERALL STATISTICS")
        report.append(f"Total Classes: {total_classes}")
        report.append(f"Classes Attended: {total_present}")
        report.append(f"Overall Attendance: {overall_percentage:.2f}%")
        report.append("")
        
        # Subject-wise breakdown
        report.append("📋 SUBJECT-WISE BREAKDOWN")
        report.append("-" * 60)
        
        for subject, data in sorted(self.subjects.items()):
            status = "✅ SAFE" if data['percentage'] >= self.minimum_attendance else "⚠️  LOW"
            
            report.append(f"Subject: {subject}")
            report.append(f"  Classes: {data['present']}/{data['total_classes']} ({data['percentage']:.2f}%) {status}")
            
            if data['percentage'] < self.minimum_attendance:
                required = self.calculate_required_classes(subject)
                report.append(f"  ⚡ Need to attend {required} more classes to reach {self.minimum_attendance}%")
            
            report.append("")
        
        # Low attendance warning
        low_subjects = self.get_low_attendance_subjects()
        if low_subjects:
            report.append("🚨 LOW ATTENDANCE WARNING")
            report.append("-" * 60)
            for subject in low_subjects:
                data = self.subjects[subject]
                required = self.calculate_required_classes(subject)
                report.append(f"• {subject}: {data['percentage']:.2f}% (Need {required} more classes)")
            report.append("")
        
        return "\n".join(report)
    
    def save_to_json(self, filename: str = "attendance_data.json"):
        """Save attendance data to JSON file"""
        data = {
            'student_name': self.student_name,
            'semester': self.semester,
            'minimum_attendance': self.minimum_attendance,
            'subjects': self.subjects,
            'last_updated': datetime.now().isoformat()
        }
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"✅ Attendance data saved to {filename}")

def run_demo():
    """Run a demo with sample data"""
    print("🎓 SIMPLE ATTENDANCE TRACKER DEMO")
    print("=" * 50)
    print("Creating sample data for a TN college student...")
    print()
    
    # Create tracker instance
    tracker = SimpleAttendanceTracker()
    
    # Set student details
    tracker.student_name = "Priya Sharma"
    tracker.semester = "5th Semester - CSE"
    tracker.minimum_attendance = 75
    
    # Add sample subjects manually
    sample_subjects = [
        ("Mathematics-III", 45, 38),
        ("Data Structures", 42, 35),
        ("Computer Networks", 40, 28),
        ("Database Management", 38, 32),
        ("Software Engineering", 35, 30),
        ("Operating Systems", 44, 25),
        ("Web Technologies", 36, 33),
        ("Technical Communication", 30, 28)
    ]
    
    for subject, total, present in sample_subjects:
        tracker.add_subject_manually(subject, total, present)
    
    print("✅ Sample data created successfully!")
    print()
    
    # Generate and display report
    print(tracker.generate_report())
    
    # Show specific calculations
    print("\n🔍 DETAILED ANALYSIS")
    print("-" * 50)
    
    low_subjects = tracker.get_low_attendance_subjects()
    if low_subjects:
        print("⚠️  Subjects needing immediate attention:")
        for subject in low_subjects:
            data = tracker.subjects[subject]
            required = tracker.calculate_required_classes(subject)
            print(f"  • {subject}: {data['percentage']:.1f}% - Need {required} more classes")
    
    print("\n📊 What-if Analysis:")
    print("If you attend 5 more classes in each low-attendance subject:")
    
    for subject in low_subjects:
        data = tracker.subjects[subject]
        new_present = data['present'] + 5
        new_total = data['total_classes'] + 5
        new_percentage = (new_present / new_total) * 100
        
        print(f"  • {subject}: {data['percentage']:.1f}% → {new_percentage:.1f}%")
    
    # Save demo data
    tracker.save_to_json("demo_attendance_data.json")
    
    print(f"\n💾 Demo data saved to 'demo_attendance_data.json'")
    print("🌐 Open 'attendance_web.html' in your browser to see the web interface!")

def main():
    """Main interactive function"""
    tracker = SimpleAttendanceTracker()
    
    print("🎓 Welcome to Simple Attendance Tracker!")
    print("Perfect for Tamil Nadu college students!")
    print()
    
    while True:
        print("\n📚 ATTENDANCE TRACKER MENU")
        print("1. Load from CSV file")
        print("2. Add subject manually")
        print("3. View attendance report")
        print("4. Set minimum attendance percentage")
        print("5. Set student details")
        print("6. Save data")
        print("7. Run demo with sample data")
        print("8. Exit")
        
        choice = input("\nEnter your choice (1-8): ").strip()
        
        if choice == '1':
            csv_file = input("Enter CSV file path: ").strip()
            if tracker.load_from_csv(csv_file):
                print("✅ CSV data loaded successfully!")
            else:
                print("❌ Failed to load CSV data")
        
        elif choice == '2':
            subject = input("Enter subject name: ").strip()
            try:
                total = int(input("Enter total classes: "))
                present = int(input("Enter classes attended: "))
                if present > total:
                    print("❌ Present classes cannot be more than total classes")
                    continue
                tracker.add_subject_manually(subject, total, present)
                print(f"✅ Added {subject} successfully!")
            except ValueError:
                print("❌ Please enter valid numbers")
        
        elif choice == '3':
            if not tracker.subjects:
                print("❌ No attendance data available. Please add some data first.")
            else:
                print(tracker.generate_report())
        
        elif choice == '4':
            try:
                new_min = float(input(f"Current minimum: {tracker.minimum_attendance}%. Enter new minimum: "))
                if 0 <= new_min <= 100:
                    tracker.minimum_attendance = new_min
                    print(f"✅ Minimum attendance set to {new_min}%")
                else:
                    print("❌ Please enter a percentage between 0 and 100")
            except ValueError:
                print("❌ Please enter a valid percentage")
        
        elif choice == '5':
            tracker.student_name = input("Enter student name: ").strip()
            tracker.semester = input("Enter semester/year: ").strip()
            print("✅ Student details updated!")
        
        elif choice == '6':
            tracker.save_to_json()
        
        elif choice == '7':
            run_demo()
            break
        
        elif choice == '8':
            print("👋 Thanks for using Attendance Tracker!")
            break
        
        else:
            print("❌ Invalid choice. Please try again.")

if __name__ == "__main__":
    # Check if running as demo or interactive
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        main()