# 🎓 Auto-Attendance Tracker for Tamil Nadu College Students

Never miss tracking your college attendance again! This tool automatically calculates attendance percentages from PDFs or CSVs and highlights subjects with low attendance.

## 🚀 Features

- **📊 Automatic Calculation**: Calculate attendance percentages for each subject
- **⚠️ Low Attendance Alerts**: Highlights subjects below minimum threshold
- **📈 Smart Predictions**: Shows how many classes you need to attend to reach target percentage
- **📄 PDF Support**: Extract attendance data directly from college PDF reports
- **💾 Data Persistence**: Save and load your attendance data
- **🌐 Web Interface**: Easy-to-use web interface for quick access
- **📱 Mobile Friendly**: Works on all devices

## 🛠️ Installation

1. **Install Python Dependencies**:
```bash
pip install -r requirements_attendance.txt
```

2. **For PDF Support** (optional):
```bash
pip install PyPDF2
```

## 📋 Quick Start

### Method 1: Command Line Interface
```bash
python attendance_tracker.py
```

### Method 2: Web Interface
Open `attendance_web.html` in your browser for a user-friendly interface.

### Method 3: CSV Upload
1. Prepare your CSV file with columns: `Subject`, `Total_Classes`, `Present_Classes`, `Absent_Classes`
2. Load it using either the CLI or web interface

## 📁 File Structure

```
attendance-tracker/
├── attendance_tracker.py      # Main CLI application
├── pdf_parser.py             # PDF extraction tool
├── attendance_web.html       # Web interface
├── sample_attendance.csv     # Sample data file
├── requirements_attendance.txt # Python dependencies
└── ATTENDANCE_README.md      # This file
```

## 📊 Sample Data

The included `sample_attendance.csv` contains realistic data for a TN college student:

| Subject | Total Classes | Present | Absent | Percentage |
|---------|---------------|---------|--------|------------|
| Mathematics-III | 45 | 38 | 7 | 84.44% |
| Data Structures | 42 | 35 | 7 | 83.33% |
| Computer Networks | 40 | 28 | 12 | 70.00% ⚠️ |
| Database Management | 38 | 32 | 6 | 84.21% |
| Software Engineering | 35 | 30 | 5 | 85.71% |
| Operating Systems | 44 | 25 | 19 | 56.82% ⚠️ |
| Web Technologies | 36 | 33 | 3 | 91.67% |
| Technical Communication | 30 | 28 | 2 | 93.33% |

## 🎯 Usage Examples

### 1. Load Sample Data
```bash
python attendance_tracker.py
# Choose option 1 and enter: sample_attendance.csv
```

### 2. Add Subject Manually
```bash
# In the CLI, choose option 2
Subject: Data Structures
Total Classes: 42
Present Classes: 35
```

### 3. Generate Report
The tool will show:
- Overall attendance percentage
- Subject-wise breakdown with status (✅ SAFE or ⚠️ LOW)
- Required classes to reach minimum percentage
- Low attendance warnings

### 4. Extract from PDF
```bash
python pdf_parser.py
# Enter your college attendance PDF path
```

## 📈 Key Features Explained

### Smart Attendance Calculation
- Automatically calculates percentages
- Shows exactly how many classes needed to reach target
- Considers future classes in calculations

### Low Attendance Alerts
- Highlights subjects below 75% (configurable)
- Shows required classes to reach minimum
- Color-coded warnings in web interface

### Data Persistence
- Save attendance data as JSON
- Load previous data on startup
- Export reports for sharing

## 🎨 Web Interface Features

- **Drag & Drop CSV**: Easy file upload
- **Real-time Updates**: Instant calculations as you type
- **Mobile Responsive**: Works on phones and tablets
- **Visual Indicators**: Color-coded cards for easy identification
- **Interactive**: Add subjects manually or upload CSV

## 🔧 Customization

### Change Minimum Attendance
```python
tracker.minimum_attendance = 80  # Set to 80%
```

### Add Custom PDF Patterns
Edit `pdf_parser.py` to add patterns specific to your college's PDF format:

```python
self.patterns['subject_attendance'].append(
    r'Your_College_Pattern_Here'
)
```

## 📱 Mobile Usage

The web interface is fully responsive and works great on mobile devices. Perfect for checking attendance on the go!

## 🚨 Common Use Cases for TN Students

1. **Anna University Affiliated Colleges**: Works with standard attendance formats
2. **Semester System**: Tracks attendance per semester
3. **Internal Assessment**: Monitor attendance for internal marks
4. **Parent Updates**: Generate reports to share with parents
5. **Academic Planning**: Plan which classes to prioritize

## 🛡️ Privacy & Security

- All data stays on your device
- No internet connection required (except for web interface)
- No data is sent to external servers
- Your attendance data remains private

## 🤝 Contributing

Feel free to contribute by:
- Adding support for more PDF formats
- Improving the web interface
- Adding new features
- Reporting bugs

## 📞 Support

For TN college students facing issues:
1. Check if your CSV format matches the expected columns
2. For PDF issues, try converting to CSV first
3. Ensure minimum attendance percentage is set correctly
4. Use the sample data to test functionality

## 🎉 Success Stories

This tool helps TN college students:
- Save 30+ minutes per week on attendance calculation
- Never miss the 75% attendance requirement
- Plan their class attendance strategically
- Generate professional reports for academic purposes

---

**Made with ❤️ for Tamil Nadu college students who hate manual attendance calculation!**

*"I hate calculating my college attendance manually" - Every TN student ever*